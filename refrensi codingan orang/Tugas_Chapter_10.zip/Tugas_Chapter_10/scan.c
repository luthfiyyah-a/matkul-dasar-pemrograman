
#include "head.h"

/*
 * Complex number input function returns standard scanning error code
 * 1 => valid scan, 0 => error, negative EOF value => end of file
 */
int
scan_complex(complex_t *c) /* output - address of complex variable to
                                       fill                              */
{
      int status;
      status = scanf("%lf%lf", &c->real, &c->imag);
      if (status == 2)
            status = 1;
      else if (status != EOF)
            status = 0;
      return (status);
}
