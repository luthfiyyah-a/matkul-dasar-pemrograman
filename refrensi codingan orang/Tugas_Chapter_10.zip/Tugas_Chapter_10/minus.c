
#include "head.h"
/*
 * Returns difference c1 - c2
 */
complex_t
subtract_complex(complex_t c1, complex_t c2) /* input parameters    */
{
      complex_t cdiff;
      cdiff.real = c1.real - c2.real;
      cdiff.imag = c1.imag - c2.imag;
      return (cdiff);
}
