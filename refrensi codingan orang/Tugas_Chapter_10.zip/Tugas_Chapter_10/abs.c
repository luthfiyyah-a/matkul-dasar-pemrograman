
#include "head.h"
/*
 * Returns absolute value of complex number c
 */
complex_t
abs_complex(complex_t c) /* input parameter                        */
{
      complex_t cabs;
      cabs.real = sqrt(c.real * c.real + c.imag * c.imag);
      cabs.imag = 0;
      return (cabs);
}
