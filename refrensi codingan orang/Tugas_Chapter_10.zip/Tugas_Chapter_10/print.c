
#include "head.h"
/*
 * Complex output function displays value as (a + bi) or (a - bi),
 * dropping a or b if they round to 0 unless both round to 0
 */
void
print_complex(complex_t c) /* input - complex number to display    */
{
	double a, b;
	char   sign;
	a = c.real;
	b = c.imag;
	printf("(");
	if (fabs(a) < .005   &&   fabs(b) < .005) {
	    printf("%.2f", 0.0);
	} else if (fabs(b) < .005) {
	    printf("%.2f", a);
	} else if (fabs(a) < .005) {
	    printf("%.2fi", b);
	} else {
		if (b < 0)
		    sign = '-';
		else
		    sign = '+';
		printf("%.2f %c %.2fi", a, sign, fabs(b));
	}
	printf(")");
}
