
#include "head.h"
/*  ** Stub **
 * Returns product of complex values c1 and c2
 */
complex_t
multiply_complex(complex_t c1, complex_t c2) /* input parameters    */
{
	complex_t multi;
    multi.imag = (c1.real * c2.imag) + (c1.imag * c2.real);
    multi.real = (c1.real * c2.real) - (c1.imag * c2.imag);
    return (multi);
}
