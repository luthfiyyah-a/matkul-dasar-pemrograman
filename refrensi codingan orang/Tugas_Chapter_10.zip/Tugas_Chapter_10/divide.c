
#include "head.h"
/*  ** Stub **
 * Returns quotient of complex values (c1 / c2)
 */
complex_t
divide_complex(complex_t c1, complex_t c2) /* input parameters    */
{
    complex_t divide;
    divide.real = (c1.real * c2.real + c1.imag * c2.imag)/(pow(c2.real,2) + pow(c2.imag, 2));
	divide.imag = (c1.imag * c2.real - c1.real * c2.imag)/(pow(c2.real,2) + pow(c2.imag, 2)); 
    return (divide);
}
