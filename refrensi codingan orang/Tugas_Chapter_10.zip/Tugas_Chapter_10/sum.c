
#include "head.h"
/*
 * Returns sum of complex values c1 and c2
 */
complex_t
add_complex(complex_t c1, complex_t c2) /* input - values to add    */
{
      complex_t csum;
      csum.real = c1.real + c2.real;
      csum.imag = c1.imag + c2.imag;
      return (csum);
}
