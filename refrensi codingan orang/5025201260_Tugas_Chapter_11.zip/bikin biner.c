

// Nama: Fadel Pramaputra Maulana
// NRP: 5025201260

// program ini untuk membuat file biner dengan menginput nama sesuai input pengguna

#include <stdio.h>
#define STR_SIZ 80 
#define SIZ 100

//typedef struct{             
//    int stock_num[SIZ];         
//    char category[STR_SIZ][SIZ];
//    char tech_descript[STR_SIZ][SIZ];
//    double price[SIZ];
//}product_t;

typedef struct{             
    int stock_num;          
    char category[STR_SIZ];
    char tech_descript[STR_SIZ];
    double price;
//    int stock_num2;          
//    char category2[STR_SIZ];
//    char tech_descript2[STR_SIZ];
//    double price2;
}product_t;

int main (){
	char nama[SIZ];
	printf("jangan lupa ketik nama file ya menggunakan .bin contoh (contoh.bin)\n= ");
	scanf("%s", nama);
	FILE* out = fopen(nama, "wb");
//	product_t params;
	
//	product_t b = {             
//	    .stock_num = 1,         
//	    .category = "a",
//	    .tech_descript = "b",
//	    .price = 2.0
//	};
	
	product_t a = {             
	    .stock_num = 2,         
	    .category = "b",
	    .tech_descript = "c",
	    .price = 3.0,
//	    .stock_num2 = 3,         
//	    .category2 = "c",
//	    .tech_descript2 = "d",
//	    .price2 = 4.0
	};
	
//	product_t c = {             
//	    .stock_num = 3,         
//	    .category = "c",
//	    .tech_descript = "d",
//	    .price = 4.0
//	};
	
//	int i=0;
//	char ch='a';
//	while (ch != 'q'){
//
//		scanf("%d", &params[i].stock_num);
//		scanf("%s", params[i].category);
//		scanf("%s", params[i].tech_descript);
//		scanf("%lf", &params[i].price);
//		
//		printf("Kalo mau nambah inventory lagi tekan huruf selain q kalau mau berhenti pencet q\n");
//		scanf(" %c", &ch);
//		i++;
//	}
//	int k;
//	for (k=0; k<2; k++){
		char ch='\n';
		fwrite(&a, sizeof(product_t), 1, out);
//		fwrite("\n", sizeof(char), 1, out);
//		fwrite(&b, sizeof(product_t), 1, out);
//		fwrite("\n", sizeof(char), 1, out);
//		fwrite(&c, sizeof(product_t), 1, out);
//		fprintf(out, "\n");
//	}
	
	
	fclose(out);
	return 0;
}
