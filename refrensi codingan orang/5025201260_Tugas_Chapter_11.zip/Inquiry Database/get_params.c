/*Problem
   Mendapatkan parameter pencarian dari pengguna
*/
/*Analisis
    Fungsi get_params harus pertama kali diinisialisasipada pencarian parameterr untuk
    mengizinkan pencarian yang luas dan membiarkan pengguna untuk mengubah beberapa parameter
    pada pencarian yang lebih sempit.

*/
/* Data Requirements
    variabel: 
		- search_params_t params = jenis struct untuk menyimpan data parameter 
		- char choice = input pengguna 
*/

/*
* Mengizinkan pengguna untuk menginput parameter
*/
#include "head.h"

search_params_t 
get_params(void){
    
    search_params_t params = {             // Parameter pencarian batasan output
    	.low_stock = 1, 
		.high_stock = 9,
    	.low_category = "a", 
		.high_category = "z",
    	.low_tech_descript = "a", 
		.high_tech_descript = "z",
    	.low_price = 0.0, 
		.high_price = 1000.0
	};
    
    char choice = menu_choose(&params);
    do{
        if(choice=='q') break;
        if(choice=='a'){
	        printf("New low bound for stock>");
	        scanf("%d",&params.low_stock);
        }
        if(choice=='b'){
            printf("New high bound for stock>");
            scanf("%d",&params.high_stock);
        }
        if(choice=='c'){
            printf("New low bound for category>");
            scanf("%s",params.low_category);
        }
        if(choice=='d'){
            printf("New high bound for category>");
            scanf("%s",params.high_category);
        }
        if(choice=='e'){
            printf("New low bound for tech description>");
            scanf("%s",params.low_tech_descript);
        }
        if(choice=='f'){
            printf("New high bound for tech description>");
            scanf("%s",params.high_tech_descript);
        }
        if(choice=='g'){
            printf("New low bound for price>");
            scanf("%lf",&params.low_price);
        }
        if(choice=='h'){
            printf("New high bound for price>");
            scanf("%lf",&params.high_price);
        }
        choice = menu_choose(&params);
    }while(choice!='q');
    return (params);
}
