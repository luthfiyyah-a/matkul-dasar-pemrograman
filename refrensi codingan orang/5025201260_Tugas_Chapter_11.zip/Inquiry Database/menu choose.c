/*
* Menampilkan jejak dari semua produk di dalam inventaris yang sesuai
* dengan pencarian parameter.
* Pre: databasep mengakses sebuah binary file dari jejak product_t yang
* telah dibuka sebagai input file, dan params terdefinisi
*/

//Memasukkan fungsi yang diperlukan oleh get_params dan display_match
#include "head.h"
char
menu_choose(search_params_t *params) //input - batasan parameter pencarian terbaru
{
	char choice;
    printf("Select by letter a search parameter to set or enter ");
    printf("q to\naccept parameters show.\n\n");
    printf("    Search Parameter                    ");
    printf("Current value\n\n");
    printf("[a] Low bound for stock number              %4d\n",params->low_stock);
    printf("[b] High bound for stock number             %4d\n",params->high_stock);
    printf("[c] Low bound for category                  %s\n",params->low_category);
    printf("[d] High bound for category                 %s\n",params->high_category);
    printf("[e] Low bound for technical description     %s\n",params->low_tech_descript);
    printf("[f] High bound for technical description    %s\n",params->high_tech_descript);
    printf("[g] Low bound for price                     $%7.2f\n",params->low_price);
    printf("[h] High bound for price                    $%7.2f\n",params->high_price);
    printf("Selection> ");
    scanf(" %c", &choice);
    return (choice);
}
