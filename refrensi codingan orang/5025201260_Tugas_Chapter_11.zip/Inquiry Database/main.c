/*Ditulis Oleh
    Nama: Fadel Pramaputra Maulana
    NRP : 5025201260
*/
/*Tanggal
    Pembuatan : Minggu, 3 Januari 2021
*/
/*Problem
   Periphs Plus adalah perusahaan penyedia computer berbasik email yang menyediakan inventaris
   berisi file komputer yang bertujuan untuk memfasilitasi jawaban atas pertanyaan-pertanyaan mengenai
   databasenya. Contoh pertanyaan terkait bisa melingkupi:
    1. Dudukan printer jenis apa yang harganya kurang dari $100 yang tersedia?
    2. Produk apa yang memiliki kode 5241?
    3. Tipe catridge apa yang tersedia?
    Pertanyaan-pertanyaan tersebut dan lainnya bisa terjawab bila kita mengetahui cara yang tepat untuk
    bertanya.
*/
/*Analisis
    Pencarian database memiliki dua fase: Mengatur parameter pencarian dan mencari jejak yang sesuai dengan
    parameter. Pada program kali ini, kita mengasumsikan bahwa semua komponen struktur bisa campur tangan
    dalam pencarian. Pengguna harus memasukkan batas bawah dan atas dari masing-masinng bidang terkait. Kita
    bisa mengilustrasikan bagaimana kita mungkin mengatur parameter pencarian untuk menjawab pertanyaan, "Modem
    jenis apa yang harganya kurang dari $200 yang tersedia?"

    Asumsikan bahwa harga produk Periphs Plus tidak lebih dari $1000, kita bisa menggunakan
    dialog menu-teratur berikut untuk mengatur parameter pencarian.

    Select by letter a search parameter to set, or enter q to
	accept parameters shown.
	Search Parameter Current Value
	[a] Low bound for stock number 1111
	[b] High bound for stock number 9999
	[c] Low bound for category aaaa
	[d] High bound for category zzzz
	[e] Low bound for technical description aaaa
	[f] High bound for technical description zzzz
	[g] Low bound for price $ 0.00
	[h] High bound for price $1000.00
	Selection> c
	New low bound for category> modem
	
	Select by letter a search parameter to set, or enter q to accept
	parameters shown.
	Search Parameter Current Value
	[a] Low bound for stock number 1111
	[b] High bound for stock number 9999
	[c] Low bound for category modem
	[d] High bound for category zzzz
	[e] Low bound for technical description aaaa
	[f] High bound for technical description zzzz
	[g] Low bound for price $ 0.00
	[h] High bound for price $1000.00
	Selection> d
	New high bound for category> modem
	
	Select by letter a search parameter to set, or enter q to accept
	parameters shown.
	Search Parameter Current Value
	[a] Low bound for stock number 1111
	[b] High bound for stock number 9999
	[c] Low bound for category modem
	[d] High bound for category modem
	[e] Low bound for technical description aaaa
	[f] High bound for technical description zzzz
	[g] Low bound for price $ 0.00
	[h] High bound for price $1000.00
	Selection> h
	New high bound for price> 199.99
	
	Select by letter a search parameter to set, or enter q to accept
	parameters shown.
	Search Parameter Current Value
	[a] Low bound for stock number 1111
	[b] High bound for stock number 9999
	[c] Low bound for category modem
	[d] High bound for category modem
	[e] Low bound for technical description aaaa
	[f] High bound for technical description zzzz
	[g] Low bound for price $ 0.00
	[h] High bound for price $ 199.99
	Selection> q
*/
/* Data Requirements
    Nilai Konstan:  
		1. #define MIN_STOCK 1111      = stok minimum
    	2. #define MAX_STOCK 9999      = stok maksimum
    	3. #define MAX_PRICE 1000.00   = harga produk maksimum
    	4. #define STR_SIZ 80          = banyaknya karakter dalam string

    Problem input:  
		- search_params_t params = batasan parameter pencarian
        - char inv_filename[STR_SIZ] = nama dari file inventaris

    Problem Output: Semua produk yang sesuai dengan pencarian
*/
/* Design
    Algoritma Program:  1. Membuka file inventaris
                        2. Mendapatkan parameter pencarian
                        3. Menampilkan semua produk yang sesuai dengan pencarian
    Refinement: 1.1 Menggunakan FILE *inventoryp - output
                2.1 Memanggil fungsi params - ouput
                3.1 Memangil fungsi params dengan inventoryp - output
*/
/*Implementasi
    Program di bawah merupakan main function yang sudah terdapat outline program sekaligus
    full code. Begitu pula untuk fungsi-fungsi yang lain, terdapat outline program yang sudah
    menyampaikan implementasi program keseluruhan.
*/

/*
* Menampilkan semua produk pada database yang sesuai dengan
* pencarian parameter yang dispesifikasi oleh pengguna program
*/
#include "head.h"
int main()
{	
    
    char inv_filename[STR_SIZ]; //Nama dari file inventaris
    FILE *inventoryp;           //Pointer dari file inventaris
    search_params_t params;     //batasan pencarian parameter
    
    //Mendapatkan nama dari file inventaris dan membukanya
	for (scanf("%s", inv_filename);
	(inventoryp = fopen(inv_filename, "rb")) == NULL;
	scanf("%s", inv_filename)) {
		printf("Cannot open %s for input\n", inv_filename);
		printf("Re-enter file name> ");
	}
	
    //Mendapatkan parameter pencarian
	params = get_params();
	
    // Menampilkan semua produk yang sesuai dengan parameter pencarian
    display_match(inventoryp, params);
    
    fclose(inventoryp);
    return 0;
}
