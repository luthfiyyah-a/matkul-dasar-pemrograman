/*Problem
   Menampilkan pasangan yang sesuai sesuai denganbatasannya
*/
/*Analisis
    Fungsi display_match harus mempelajari masing-masing jejak file dengan jumlah stok
    antara batas atas dan bawah. Bila jejaknya sesuai dengan pencarian, maka akan ditampilkan.
    Fungsi display_match juga menampilkan pesan jika tidak ada pasangan yang sesuai.

*/
/* Data Requirements
	variabel: 
		- product_t next_prod = produk saat ini
		- no_matches = suatu tanda yang mengindikasikan ada tidaknya pasangan
*/

#include "head.h"
/*
* Menampilkan jejak dari semua produk pada inventaris yang sesuai dengan parameter
* pencarian.
* Pre: databasep mengakses suatu binary file dari jejak product_t yang
*      telah dibuka sebagai input file, dan params terdefinisi
*/
void display_match(FILE *databasep//file pointer ke database binary file
                   , search_params_t params//input - parameter pencarian
                   )
{
    product_t next_prod; 
    int no_matches = 1;     //penanda yang menunjukkan jika tidak ada pasangan yang sesuai
                            //yang ditemukan
    int status;

	//Mengembangkan jejak pertama dengan jumlah stok lebih besar atau sama dengan batas bawah
	for (status = fread(&next_prod, sizeof(product_t), 1, databasep);
	    status == 1 && params.low_stock > next_prod.stock_num ;
	    status = fread(&next_prod, sizeof(product_t), 1, databasep)){
	    }
	
	// Menampilkan sebuah daftar produk yang sesuai dengan pencarian parameter
    printf("\nProducts satisfying the search parameters:\n");
    while (next_prod.stock_num <= params.high_stock && status==1){
    	fread(&params, sizeof(product_t), 1, databasep);
        if(match(next_prod,params)){
            no_matches = 0;
            show(next_prod);
        }
        status = fread(&next_prod,sizeof(product_t),1,databasep);
    }
	// Menampilkan pesan bila tidak ada produk yang ditemukan
	if(no_matches) printf("Sorry, no products available\n");
}
