#include "head.h"
/*
* Menampilkan masing masing jenis produk. Meninggalkan baris kosong setelah
* semua produk ditampilkan
*/
void show(product_t prod){
    printf("Function show entered with product number %d\n", prod.stock_num);
    printf("Function show entered with product category %s\n", prod.category);
    printf("Function show entered with product tech description %s\n", prod.tech_descript);
    printf("Function show entered with product price %.2lf\n", prod.price);
}
