#include "head.h"
/*
* Menentukan apakah jejak produk sesuai dengan semua parameter pencarian
*/
int match(product_t prod,//input - jejak untuk dicek
          search_params_t params)//input - parameter untuk disesuaikan)
{
    return( strcmp(params.low_category, prod.category)<=0           &&
            strcmp(prod.category, params.high_category)<=0           &&
            strcmp(params.low_tech_descript, prod.tech_descript)<=0  &&
            strcmp(prod.tech_descript, params.high_tech_descript)<=0 &&
            params.low_price <= prod.price                           &&
            prod.price <= params.high_price);
}
