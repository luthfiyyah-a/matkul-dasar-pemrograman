#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MIN_STOCK 1111      // stok minimum
#define MAX_STOCK 9999      // stok maksimum
#define MAX_PRICE 1000.00   // harga produk maksimum
#define STR_SIZ 80          // banyaknya karakter dalam string

typedef struct{             // Tipe struct untuk produk
    int stock_num;          // banyaknya stok
    char category[STR_SIZ];
    char tech_descript[STR_SIZ];
    double price;
}product_t;

typedef struct{             // Parameter pencarian batasan output
    int low_stock, high_stock;
    char low_category[STR_SIZ], high_category[STR_SIZ];
    char low_tech_descript[STR_SIZ], high_tech_descript[STR_SIZ];
    double low_price, high_price;
}search_params_t;

search_params_t get_params(void);
void display_match (FILE *databasep, search_params_t params);
char menu_choose(search_params_t *params);
int match(product_t prod,search_params_t params);
void show(product_t prod);

// Menuliskan prototipe fungsi yang diperlukan untuk get_params dan display_match
